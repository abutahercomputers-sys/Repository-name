import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { GalleryContent } from '@/components/gallery-content'

export const metadata = {
  title: 'গ্যালারি | Gallery - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'আমাদের ফটো গ্যালারি দেখুন - View our photo gallery',
}

export const revalidate = 60

export default async function GalleryPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  // Fetch gallery items
  const { data: gallery } = await supabase
    .from('gallery')
    .select('*')
    .eq('is_published', true)
    .order('display_order', { ascending: true })
    .order('created_at', { ascending: false })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <GalleryContent gallery={gallery || []} />
      </main>
      <Footer />
    </div>
  )
}
