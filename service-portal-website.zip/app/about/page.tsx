import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { AboutContent } from '@/components/about-content'

export const metadata = {
  title: 'আমাদের সম্পর্কে | About Us - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ সম্পর্কে জানুন - Learn about Shibpur Meghsimul Funny Content Group',
}

export default async function AboutPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <AboutContent />
      </main>
      <Footer />
    </div>
  )
}
