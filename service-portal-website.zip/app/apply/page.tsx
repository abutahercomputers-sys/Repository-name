import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ApplyContent } from '@/components/apply-content'

export const metadata = {
  title: 'অনলাইন আবেদন | Apply Online - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'অনলাইনে আবেদন করুন - Apply online for services',
}

export default async function ApplyPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  // Redirect to login if not authenticated
  if (!user) {
    redirect('/auth/login?redirect=/apply')
  }
  
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()
    
  const userProfile = profile ? { email: user.email || '', role: profile.role } : null

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <ApplyContent user={user} profile={profile} />
      </main>
      <Footer />
    </div>
  )
}
