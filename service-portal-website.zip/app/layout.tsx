import type { Metadata } from 'next'
import { Geist, Geist_Mono, Hind_Siliguri } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from '@/components/ui/sonner'
import { LanguageProvider } from '@/lib/language-context'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist' })
const geistMono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })
const hindSiliguri = Hind_Siliguri({ 
  weight: ['300', '400', '500', '600', '700'],
  subsets: ['bengali', 'latin'],
  variable: '--font-hind-siliguri'
})

export const metadata: Metadata = {
  title: 'শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ | Shibpur Meghsimul Funny Content Group',
  description: 'শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা, বাংলাদেশ - Official Service Portal for Employee Management, Online Applications, and Community Services',
  keywords: ['শিবপুর', 'মেঘশিমূল', 'পূর্বধলা', 'নেত্রকোণা', 'বাংলাদেশ', 'সার্ভিস পোর্টাল'],
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="bn" className="bg-background">
      <body className={`${geist.variable} ${geistMono.variable} ${hindSiliguri.variable} font-sans antialiased`}>
        <LanguageProvider>
          {children}
          <Toaster position="top-right" />
        </LanguageProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
