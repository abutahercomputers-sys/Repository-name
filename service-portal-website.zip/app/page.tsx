import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { HomeContent } from '@/components/home-content'

export const revalidate = 60 // Revalidate every minute

export default async function HomePage() {
  const supabase = await createClient()
  
  // Fetch current user
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  // Fetch latest notices
  const { data: notices } = await supabase
    .from('notices')
    .select('id, title, title_bn, published_at, category, is_pinned')
    .eq('is_published', true)
    .order('is_pinned', { ascending: false })
    .order('published_at', { ascending: false })
    .limit(6)

  // Fetch featured employees
  const { data: employees } = await supabase
    .from('employees')
    .select('id, name, name_bn, designation, designation_bn, photo_url')
    .eq('is_active', true)
    .order('display_order', { ascending: true })
    .limit(4)

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <HomeContent 
          notices={notices || []} 
          employees={employees || []} 
        />
      </main>
      <Footer />
    </div>
  )
}
