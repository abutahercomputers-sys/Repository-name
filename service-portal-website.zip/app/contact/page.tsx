import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ContactContent } from '@/components/contact-content'

export const metadata = {
  title: 'যোগাযোগ | Contact - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'আমাদের সাথে যোগাযোগ করুন - Contact us',
}

export default async function ContactPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <ContactContent />
      </main>
      <Footer />
    </div>
  )
}
