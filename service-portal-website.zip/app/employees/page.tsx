import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { EmployeesContent } from '@/components/employees-content'

export const metadata = {
  title: 'কর্মচারী | Employees - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'আমাদের কর্মচারীদের সম্পর্কে জানুন - Meet our team members',
}

export const revalidate = 60

export default async function EmployeesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  // Fetch employees
  const { data: employees } = await supabase
    .from('employees')
    .select('*')
    .eq('is_active', true)
    .order('display_order', { ascending: true })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <EmployeesContent employees={employees || []} />
      </main>
      <Footer />
    </div>
  )
}
