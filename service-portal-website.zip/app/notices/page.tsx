import { createClient } from '@/lib/supabase/server'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { NoticesContent } from '@/components/notices-content'

export const metadata = {
  title: 'নোটিশ বোর্ড | Notice Board - শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ',
  description: 'সর্বশেষ নোটিশ ও ঘোষণা দেখুন - View latest notices and announcements',
}

export const revalidate = 60

export default async function NoticesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  let userProfile = null
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
    userProfile = profile ? { email: user.email || '', role: profile.role } : null
  }

  // Fetch notices
  const { data: notices } = await supabase
    .from('notices')
    .select('*')
    .eq('is_published', true)
    .order('is_pinned', { ascending: false })
    .order('published_at', { ascending: false })

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={userProfile} />
      <main className="flex-1">
        <NoticesContent notices={notices || []} />
      </main>
      <Footer />
    </div>
  )
}
