'use client'

import { useState } from 'react'
import { useLanguage, translations } from '@/lib/language-context'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { MapPin, Phone, Mail, Clock, Send, Loader2 } from 'lucide-react'

export function ContactContent() {
  const { t } = useLanguage()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const supabase = createClient()
      const { error } = await supabase
        .from('contact_messages')
        .insert([formData])

      if (error) throw error

      toast.success(t('বার্তা সফলভাবে পাঠানো হয়েছে', 'Message sent successfully'))
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' })
    } catch (error) {
      console.error('Error:', error)
      toast.error(t('বার্তা পাঠাতে ব্যর্থ হয়েছে', 'Failed to send message'))
    } finally {
      setLoading(false)
    }
  }

  const contactInfo = [
    {
      icon: MapPin,
      title: { bn: 'ঠিকানা', en: 'Address' },
      content: { 
        bn: 'শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা-২৪৩০, বাংলাদেশ', 
        en: 'Shibpur/Meghsimul, Purbadhala, Netrokona-2430, Bangladesh' 
      }
    },
    {
      icon: Phone,
      title: { bn: 'ফোন', en: 'Phone' },
      content: { bn: '+৮৮০ ১৭০০-০০০০০০', en: '+880 1700-000000' },
      href: 'tel:+8801700000000'
    },
    {
      icon: Mail,
      title: { bn: 'ইমেইল', en: 'Email' },
      content: { bn: 'info@shibpurmeghsimul.com', en: 'info@shibpurmeghsimul.com' },
      href: 'mailto:info@shibpurmeghsimul.com'
    },
    {
      icon: Clock,
      title: { bn: 'অফিস সময়', en: 'Office Hours' },
      content: { bn: 'রবি - বৃহস্পতি: সকাল ৯টা - বিকাল ৫টা', en: 'Sun - Thu: 9:00 AM - 5:00 PM' }
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('যোগাযোগ করুন', 'Contact Us')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'আপনার যেকোনো প্রশ্ন বা মতামত আমাদের জানান',
                'Let us know your questions or feedback'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Contact Info */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold mb-6">
                {t(translations.contactInfo.bn, translations.contactInfo.en)}
              </h2>
              {contactInfo.map((info, index) => (
                <Card key={index}>
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <info.icon className="size-5" />
                    </div>
                    <div>
                      <h3 className="font-medium">
                        {t(info.title.bn, info.title.en)}
                      </h3>
                      {info.href ? (
                        <a 
                          href={info.href}
                          className="text-sm text-muted-foreground hover:text-primary"
                        >
                          {t(info.content.bn, info.content.en)}
                        </a>
                      ) : (
                        <p className="text-sm text-muted-foreground">
                          {t(info.content.bn, info.content.en)}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Map Placeholder */}
              <Card className="overflow-hidden">
                <div className="aspect-video bg-muted flex items-center justify-center">
                  <div className="text-center p-4">
                    <MapPin className="size-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {t('মানচিত্র শীঘ্রই যোগ করা হবে', 'Map coming soon')}
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Contact Form */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>{t('বার্তা পাঠান', 'Send Message')}</CardTitle>
                <CardDescription>
                  {t(
                    'নিচের ফর্মটি পূরণ করে আমাদের কাছে বার্তা পাঠান',
                    'Fill out the form below to send us a message'
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">{t(translations.fullName.bn, translations.fullName.en)} *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">{t(translations.email.bn, translations.email.en)} *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="phone">{t(translations.phone.bn, translations.phone.en)}</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">{t(translations.subject.bn, translations.subject.en)} *</Label>
                      <Input
                        id="subject"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">{t(translations.message.bn, translations.message.en)} *</Label>
                    <Textarea
                      id="message"
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                    />
                  </div>
                  <Button type="submit" disabled={loading} className="w-full sm:w-auto">
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 size-4 animate-spin" />
                        {t('পাঠানো হচ্ছে...', 'Sending...')}
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 size-4" />
                        {t('বার্তা পাঠান', 'Send Message')}
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
