'use client'

import Link from 'next/link'
import { useLanguage, translations } from '@/lib/language-context'
import { Facebook, Youtube, Phone, Mail, MapPin } from 'lucide-react'

export function Footer() {
  const { t } = useLanguage()

  const quickLinks = [
    { href: '/about', label: translations.about },
    { href: '/services', label: translations.services },
    { href: '/employees', label: translations.employees },
    { href: '/apply', label: translations.apply },
    { href: '/notices', label: translations.notices },
    { href: '/contact', label: translations.contact },
  ]

  const services = [
    { bn: 'অনলাইন আবেদন', en: 'Online Application' },
    { bn: 'সনদ যাচাই', en: 'Certificate Verification' },
    { bn: 'কর্মচারী তথ্য', en: 'Employee Directory' },
    { bn: 'নোটিশ বোর্ড', en: 'Notice Board' },
    { bn: 'ডকুমেন্ট ডাউনলোড', en: 'Document Download' },
  ]

  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Organization Info */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="flex size-12 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground font-bold text-xl">
                SM
              </div>
              <div>
                <h3 className="font-bold text-lg">
                  {t('শিবপুর মেঘশিমূল', 'Shibpur Meghsimul')}
                </h3>
                <p className="text-sm text-sidebar-foreground/70">
                  {t('ফানি কন্টেন্ট গ্রুপ', 'Funny Content Group')}
                </p>
              </div>
            </div>
            <p className="text-sm text-sidebar-foreground/80 mb-4">
              {t(
                'শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা, বাংলাদেশ এর অফিসিয়াল সার্ভিস পোর্টাল।',
                'Official service portal of Shibpur/Meghsimul, Purbadhala, Netrokona, Bangladesh.'
              )}
            </p>
            <div className="flex gap-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex size-9 items-center justify-center rounded-full bg-sidebar-accent hover:bg-sidebar-primary transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="size-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex size-9 items-center justify-center rounded-full bg-sidebar-accent hover:bg-sidebar-primary transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="size-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">
              {t(translations.quickLinks.bn, translations.quickLinks.en)}
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-sidebar-foreground/80 hover:text-sidebar-foreground transition-colors"
                  >
                    {t(link.label.bn, link.label.en)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-lg mb-4">
              {t(translations.services.bn, translations.services.en)}
            </h4>
            <ul className="space-y-2">
              {services.map((service, index) => (
                <li key={index}>
                  <span className="text-sm text-sidebar-foreground/80">
                    {t(service.bn, service.en)}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-lg mb-4">
              {t(translations.contactInfo.bn, translations.contactInfo.en)}
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="size-5 text-sidebar-primary shrink-0 mt-0.5" />
                <span className="text-sm text-sidebar-foreground/80">
                  {t(
                    'শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা-২৪৩০, বাংলাদেশ',
                    'Shibpur/Meghsimul, Purbadhala, Netrokona-2430, Bangladesh'
                  )}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="size-5 text-sidebar-primary shrink-0" />
                <a
                  href="tel:+8801700000000"
                  className="text-sm text-sidebar-foreground/80 hover:text-sidebar-foreground"
                >
                  +880 1700-000000
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="size-5 text-sidebar-primary shrink-0" />
                <a
                  href="mailto:info@shibpurmeghsimul.com"
                  className="text-sm text-sidebar-foreground/80 hover:text-sidebar-foreground"
                >
                  info@shibpurmeghsimul.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-sidebar-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-sidebar-foreground/70">
              {t(translations.copyright.bn, translations.copyright.en)}
            </p>
            <div className="flex gap-4 text-sm text-sidebar-foreground/70">
              <Link href="/privacy" className="hover:text-sidebar-foreground">
                {t('গোপনীয়তা নীতি', 'Privacy Policy')}
              </Link>
              <Link href="/terms" className="hover:text-sidebar-foreground">
                {t('শর্তাবলী', 'Terms of Service')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
