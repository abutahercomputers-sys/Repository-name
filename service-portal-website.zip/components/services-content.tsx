'use client'

import Link from 'next/link'
import { useLanguage } from '@/lib/language-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  FileText, 
  ClipboardCheck, 
  Users, 
  FileImage, 
  Download, 
  Shield,
  ArrowRight,
  CheckCircle
} from 'lucide-react'

export function ServicesContent() {
  const { t } = useLanguage()

  const services = [
    {
      icon: FileText,
      title: { bn: 'অনলাইন আবেদন', en: 'Online Application' },
      description: { 
        bn: 'বিভিন্ন ধরনের সনদ ও সেবার জন্য অনলাইনে আবেদন করুন। ঘরে বসেই সহজে আবেদন সম্পন্ন করুন।', 
        en: 'Apply online for various types of certificates and services. Complete your application easily from home.' 
      },
      features: [
        { bn: 'সহজ আবেদন প্রক্রিয়া', en: 'Easy application process' },
        { bn: 'ডকুমেন্ট আপলোড সুবিধা', en: 'Document upload facility' },
        { bn: 'আবেদনের অবস্থা ট্র্যাকিং', en: 'Application status tracking' },
        { bn: 'এসএমএস নোটিফিকেশন', en: 'SMS notification' },
      ],
      href: '/apply',
      badge: { bn: 'জনপ্রিয়', en: 'Popular' }
    },
    {
      icon: ClipboardCheck,
      title: { bn: 'সনদ যাচাই', en: 'Certificate Verification' },
      description: { 
        bn: 'আপনার সনদ ও ডকুমেন্ট অনলাইনে যাচাই করুন। সত্যতা নিশ্চিত করুন।', 
        en: 'Verify your certificates and documents online. Ensure authenticity.' 
      },
      features: [
        { bn: 'দ্রুত যাচাই', en: 'Quick verification' },
        { bn: 'QR কোড স্ক্যান', en: 'QR code scan' },
        { bn: 'সনদ নম্বর দিয়ে যাচাই', en: 'Verify by certificate number' },
        { bn: 'প্রিন্ট সুবিধা', en: 'Print facility' },
      ],
      href: '/verify',
      badge: null
    },
    {
      icon: Users,
      title: { bn: 'কর্মচারী তথ্য', en: 'Employee Directory' },
      description: { 
        bn: 'আমাদের কর্মচারীদের সম্পর্কে বিস্তারিত জানুন। যোগাযোগের তথ্য পান।', 
        en: 'Learn about our employees in detail. Get contact information.' 
      },
      features: [
        { bn: 'কর্মচারী প্রোফাইল', en: 'Employee profiles' },
        { bn: 'বিভাগ অনুযায়ী তথ্য', en: 'Department-wise information' },
        { bn: 'যোগাযোগের তথ্য', en: 'Contact details' },
        { bn: 'দায়িত্ব ও কর্তব্য', en: 'Roles and responsibilities' },
      ],
      href: '/employees',
      badge: null
    },
    {
      icon: FileImage,
      title: { bn: 'ফটো গ্যালারি', en: 'Photo Gallery' },
      description: { 
        bn: 'আমাদের কার্যক্রমের ছবি দেখুন। বিভিন্ন ইভেন্ট ও অনুষ্ঠানের ছবি।', 
        en: 'View photos of our activities. Pictures of various events and programs.' 
      },
      features: [
        { bn: 'ইভেন্ট ফটো', en: 'Event photos' },
        { bn: 'অফিস কার্যক্রম', en: 'Office activities' },
        { bn: 'সামাজিক কর্মকাণ্ড', en: 'Social activities' },
        { bn: 'HD ছবি ডাউনলোড', en: 'HD image download' },
      ],
      href: '/gallery',
      badge: null
    },
    {
      icon: Download,
      title: { bn: 'ফরম ডাউনলোড', en: 'Form Download' },
      description: { 
        bn: 'প্রয়োজনীয় ফরম ও ডকুমেন্ট ডাউনলোড করুন। PDF ফরম্যাটে উপলব্ধ।', 
        en: 'Download necessary forms and documents. Available in PDF format.' 
      },
      features: [
        { bn: 'আবেদন ফরম', en: 'Application forms' },
        { bn: 'চুক্তিপত্র', en: 'Contract forms' },
        { bn: 'নমুনা ডকুমেন্ট', en: 'Sample documents' },
        { bn: 'গাইডলাইন', en: 'Guidelines' },
      ],
      href: '/downloads',
      badge: { bn: 'নতুন', en: 'New' }
    },
    {
      icon: Shield,
      title: { bn: 'নিরাপত্তা সেবা', en: 'Security Services' },
      description: { 
        bn: 'আপনার তথ্যের নিরাপত্তা আমাদের অগ্রাধিকার। সম্পূর্ণ সুরক্ষিত প্ল্যাটফর্ম।', 
        en: 'Security of your information is our priority. Completely secure platform.' 
      },
      features: [
        { bn: 'ডেটা এনক্রিপশন', en: 'Data encryption' },
        { bn: 'সিকিউর লগইন', en: 'Secure login' },
        { bn: 'প্রাইভেসি সুরক্ষা', en: 'Privacy protection' },
        { bn: '২৪/৭ মনিটরিং', en: '24/7 monitoring' },
      ],
      href: '/security',
      badge: null
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('আমাদের সেবাসমূহ', 'Our Services')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'আমরা বিভিন্ন ধরনের অনলাইন সেবা প্রদান করি। নিচে আমাদের সেবাসমূহ দেখুন।',
                'We provide various types of online services. See our services below.'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service, index) => (
              <Card key={index} className="flex flex-col hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex size-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <service.icon className="size-6" />
                    </div>
                    {service.badge && (
                      <Badge variant="secondary">
                        {t(service.badge.bn, service.badge.en)}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl">
                    {t(service.title.bn, service.title.en)}
                  </CardTitle>
                  <CardDescription className="text-sm">
                    {t(service.description.bn, service.description.en)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-2 mb-6 flex-1">
                    {service.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="size-4 text-primary shrink-0" />
                        <span className="text-muted-foreground">
                          {t(feature.bn, feature.en)}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={service.href}>
                      {t('বিস্তারিত দেখুন', 'Learn More')}
                      <ArrowRight className="ml-2 size-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            {t('সেবা নিতে প্রস্তুত?', 'Ready to Get Started?')}
          </h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            {t(
              'আজই আমাদের অনলাইন সেবা ব্যবহার করুন এবং ঘরে বসেই আপনার প্রয়োজনীয় কাজ সম্পন্ন করুন।',
              'Use our online services today and complete your required tasks from home.'
            )}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/apply">
                {t('এখনই আবেদন করুন', 'Apply Now')}
                <ArrowRight className="ml-2 size-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/contact">
                {t('যোগাযোগ করুন', 'Contact Us')}
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
