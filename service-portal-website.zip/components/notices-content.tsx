'use client'

import { useState } from 'react'
import { useLanguage } from '@/lib/language-context'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Bell, Pin, Calendar, FileText, Search, Download } from 'lucide-react'

interface Notice {
  id: string
  title: string
  title_bn: string | null
  content: string
  content_bn: string | null
  category: string
  attachment_url: string | null
  is_pinned: boolean
  published_at: string
}

interface NoticesContentProps {
  notices: Notice[]
}

export function NoticesContent({ notices }: NoticesContentProps) {
  const { t } = useLanguage()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [expandedNotice, setExpandedNotice] = useState<string | null>(null)

  // Get unique categories
  const categories = Array.from(new Set(notices.map(n => n.category)))

  // Filter notices
  const filteredNotices = notices.filter(notice => {
    const matchesSearch = notice.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (notice.title_bn && notice.title_bn.includes(searchTerm)) ||
      notice.content.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = !selectedCategory || notice.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('নোটিশ বোর্ড', 'Notice Board')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'সর্বশেষ নোটিশ, ঘোষণা ও আপডেট দেখুন',
                'View latest notices, announcements and updates'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-6 bg-card border-b sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder={t('নোটিশ খুঁজুন...', 'Search notices...')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={selectedCategory === null ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(null)}
              >
                {t('সব', 'All')}
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Notices List */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {filteredNotices.length > 0 ? (
            <div className="space-y-4">
              {filteredNotices.map((notice) => (
                <Card 
                  key={notice.id} 
                  className={`hover:shadow-md transition-shadow ${notice.is_pinned ? 'border-primary/50 bg-primary/5' : ''}`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        {notice.is_pinned && (
                          <Badge variant="destructive" className="gap-1">
                            <Pin className="size-3" />
                            {t('পিন করা', 'Pinned')}
                          </Badge>
                        )}
                        <Badge variant="secondary">{notice.category}</Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="size-4" />
                        {new Date(notice.published_at).toLocaleDateString(
                          t('bn-BD', 'en-US'),
                          { year: 'numeric', month: 'long', day: 'numeric' }
                        )}
                      </div>
                    </div>
                    <CardTitle className="text-lg mt-2">
                      {t(notice.title_bn || notice.title, notice.title)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-muted-foreground ${expandedNotice === notice.id ? '' : 'line-clamp-3'}`}>
                      {t(notice.content_bn || notice.content, notice.content)}
                    </div>
                    <div className="flex items-center gap-3 mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedNotice(expandedNotice === notice.id ? null : notice.id)}
                      >
                        {expandedNotice === notice.id 
                          ? t('কম দেখুন', 'Show Less') 
                          : t('আরও দেখুন', 'Read More')}
                      </Button>
                      {notice.attachment_url && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={notice.attachment_url} target="_blank" rel="noopener noreferrer">
                            <Download className="mr-2 size-4" />
                            {t('ডাউনলোড', 'Download')}
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <Bell className="size-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {t('কোনো নোটিশ নেই', 'No Notices Found')}
              </h3>
              <p className="text-muted-foreground">
                {searchTerm || selectedCategory
                  ? t('আপনার অনুসন্ধানে কোনো নোটিশ পাওয়া যায়নি', 'No notices match your search criteria')
                  : t('নোটিশ শীঘ্রই যোগ করা হবে', 'Notices will be added soon')}
              </p>
            </Card>
          )}
        </div>
      </section>
    </div>
  )
}
