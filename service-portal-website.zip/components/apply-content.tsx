'use client'

import { useState } from 'react'
import { useLanguage, translations } from '@/lib/language-context'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import { FileText, Loader2, CheckCircle } from 'lucide-react'
import type { User } from '@supabase/supabase-js'

interface Profile {
  id: string
  full_name: string | null
  phone: string | null
  address: string | null
}

interface ApplyContentProps {
  user: User
  profile: Profile | null
}

export function ApplyContent({ user, profile }: ApplyContentProps) {
  const { t } = useLanguage()
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    application_type: '',
    applicant_name: profile?.full_name || '',
    applicant_name_bn: '',
    father_name: '',
    mother_name: '',
    phone: profile?.phone || '',
    email: user.email || '',
    address: profile?.address || '',
    nid_number: '',
    birth_date: '',
    purpose: ''
  })

  const applicationTypes = [
    { value: 'certificate', label: { bn: 'সনদপত্র', en: 'Certificate' } },
    { value: 'membership', label: { bn: 'সদস্যপদ আবেদন', en: 'Membership Application' } },
    { value: 'employment', label: { bn: 'চাকরির আবেদন', en: 'Employment Application' } },
    { value: 'general', label: { bn: 'সাধারণ আবেদন', en: 'General Application' } },
    { value: 'contract', label: { bn: 'চুক্তি আবেদন', en: 'Contract Application' } },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const supabase = createClient()
      const { error } = await supabase
        .from('applications')
        .insert([{
          ...formData,
          user_id: user.id
        }])

      if (error) throw error

      setSubmitted(true)
      toast.success(t('আবেদন সফলভাবে জমা হয়েছে', 'Application submitted successfully'))
    } catch (error) {
      console.error('Error:', error)
      toast.error(t('আবেদন জমা দিতে ব্যর্থ হয়েছে', 'Failed to submit application'))
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="flex flex-col">
        <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl text-center text-primary-foreground">
              <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
                {t('আবেদন সফল', 'Application Successful')}
              </h1>
            </div>
          </div>
        </section>
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Card className="max-w-lg mx-auto text-center">
              <CardContent className="pt-8 pb-8">
                <CheckCircle className="size-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">
                  {t('আবেদন সফলভাবে জমা হয়েছে!', 'Application Submitted Successfully!')}
                </h2>
                <p className="text-muted-foreground mb-6">
                  {t(
                    'আপনার আবেদন আমাদের কাছে পৌঁছে গেছে। আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।',
                    'Your application has reached us. We will contact you soon.'
                  )}
                </p>
                <div className="flex gap-4 justify-center">
                  <Button onClick={() => setSubmitted(false)}>
                    {t('নতুন আবেদন', 'New Application')}
                  </Button>
                  <Button variant="outline" asChild>
                    <a href="/dashboard">{t('ড্যাশবোর্ড', 'Dashboard')}</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    )
  }

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('অনলাইন আবেদন', 'Online Application')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'নিচের ফর্মটি পূরণ করে আবেদন জমা দিন',
                'Fill out the form below to submit your application'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="size-5" />
                {t('আবেদন ফর্ম', 'Application Form')}
              </CardTitle>
              <CardDescription>
                {t(
                  'সকল তারকা (*) চিহ্নিত ঘর পূরণ করা আবশ্যক',
                  'All fields marked with asterisk (*) are required'
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Application Type */}
                <div className="space-y-2">
                  <Label>{t('আবেদনের ধরন', 'Application Type')} *</Label>
                  <Select
                    value={formData.application_type}
                    onValueChange={(value) => setFormData({ ...formData, application_type: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('আবেদনের ধরন নির্বাচন করুন', 'Select application type')} />
                    </SelectTrigger>
                    <SelectContent>
                      {applicationTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {t(type.label.bn, type.label.en)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Personal Information */}
                <div className="space-y-4">
                  <h3 className="font-semibold border-b pb-2">
                    {t('ব্যক্তিগত তথ্য', 'Personal Information')}
                  </h3>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="applicant_name">{t('নাম (ইংরেজিতে)', 'Name (English)')} *</Label>
                      <Input
                        id="applicant_name"
                        value={formData.applicant_name}
                        onChange={(e) => setFormData({ ...formData, applicant_name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="applicant_name_bn">{t('নাম (বাংলায়)', 'Name (Bangla)')}</Label>
                      <Input
                        id="applicant_name_bn"
                        value={formData.applicant_name_bn}
                        onChange={(e) => setFormData({ ...formData, applicant_name_bn: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="father_name">{t(translations.fatherName.bn, translations.fatherName.en)}</Label>
                      <Input
                        id="father_name"
                        value={formData.father_name}
                        onChange={(e) => setFormData({ ...formData, father_name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mother_name">{t(translations.motherName.bn, translations.motherName.en)}</Label>
                      <Input
                        id="mother_name"
                        value={formData.mother_name}
                        onChange={(e) => setFormData({ ...formData, mother_name: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="birth_date">{t(translations.birthDate.bn, translations.birthDate.en)}</Label>
                      <Input
                        id="birth_date"
                        type="date"
                        value={formData.birth_date}
                        onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="nid_number">{t(translations.nidNumber.bn, translations.nidNumber.en)}</Label>
                      <Input
                        id="nid_number"
                        value={formData.nid_number}
                        onChange={(e) => setFormData({ ...formData, nid_number: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="space-y-4">
                  <h3 className="font-semibold border-b pb-2">
                    {t('যোগাযোগের তথ্য', 'Contact Information')}
                  </h3>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="phone">{t(translations.phone.bn, translations.phone.en)} *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">{t(translations.email.bn, translations.email.en)}</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">{t(translations.address.bn, translations.address.en)}</Label>
                    <Textarea
                      id="address"
                      rows={2}
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    />
                  </div>
                </div>

                {/* Purpose */}
                <div className="space-y-2">
                  <Label htmlFor="purpose">{t('আবেদনের কারণ/উদ্দেশ্য', 'Purpose of Application')}</Label>
                  <Textarea
                    id="purpose"
                    rows={4}
                    value={formData.purpose}
                    onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                    placeholder={t('আপনার আবেদনের কারণ বিস্তারিত লিখুন', 'Write the details of your application purpose')}
                  />
                </div>

                <Button type="submit" disabled={loading} className="w-full">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 size-4 animate-spin" />
                      {t('জমা দেওয়া হচ্ছে...', 'Submitting...')}
                    </>
                  ) : (
                    t('আবেদন জমা দিন', 'Submit Application')
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
