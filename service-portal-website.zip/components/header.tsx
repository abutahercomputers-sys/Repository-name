'use client'

import Link from 'next/link'
import { useState } from 'react'
import { useLanguage, translations } from '@/lib/language-context'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { Menu, Globe, User, ChevronDown } from 'lucide-react'

interface HeaderProps {
  user?: { email: string; role: string } | null
}

export function Header({ user }: HeaderProps) {
  const { language, setLanguage, t } = useLanguage()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navLinks = [
    { href: '/', label: translations.home },
    { href: '/about', label: translations.about },
    { href: '/services', label: translations.services },
    { href: '/employees', label: translations.employees },
    { href: '/apply', label: translations.apply },
    { href: '/notices', label: translations.notices },
    { href: '/gallery', label: translations.gallery },
    { href: '/contact', label: translations.contact },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto flex items-center justify-between px-4 py-2 text-sm">
          <span className="hidden md:inline-block">
            {t('শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা', 'Shibpur/Meghsimul, Purbadhala, Netrokona')}
          </span>
          <div className="flex items-center gap-4 ml-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 text-primary-foreground hover:text-primary-foreground/80 hover:bg-primary/80">
                  <Globe className="mr-1 size-4" />
                  {language === 'bn' ? 'বাংলা' : 'English'}
                  <ChevronDown className="ml-1 size-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLanguage('bn')}>
                  বাংলা
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('en')}>
                  English
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-lg">
              SM
            </div>
            <div className="hidden sm:block">
              <h1 className="text-base font-bold leading-tight text-foreground">
                {t('শিবপুর মেঘশিমূল', 'Shibpur Meghsimul')}
              </h1>
              <p className="text-xs text-muted-foreground">
                {t('ফানি কন্টেন্ট গ্রুপ', 'Funny Content Group')}
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
              >
                {t(link.label.bn, link.label.en)}
              </Link>
            ))}
          </nav>

          {/* User Actions */}
          <div className="flex items-center gap-2">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <User className="mr-2 size-4" />
                    {user.email.split('@')[0]}
                    <ChevronDown className="ml-1 size-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">{t(translations.dashboard.bn, translations.dashboard.en)}</Link>
                  </DropdownMenuItem>
                  {user.role === 'admin' && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin">{t(translations.admin.bn, translations.admin.en)}</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <Link href="/auth/logout">{t(translations.logout.bn, translations.logout.en)}</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/auth/login">{t(translations.login.bn, translations.login.en)}</Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href="/auth/sign-up">{t(translations.signup.bn, translations.signup.en)}</Link>
                </Button>
              </div>
            )}

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="size-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <SheetTitle className="text-left">
                  {t('মেনু', 'Menu')}
                </SheetTitle>
                <nav className="mt-6 flex flex-col gap-2">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
                    >
                      {t(link.label.bn, link.label.en)}
                    </Link>
                  ))}
                  {!user && (
                    <>
                      <hr className="my-2" />
                      <Link
                        href="/auth/login"
                        onClick={() => setMobileMenuOpen(false)}
                        className="px-3 py-2 text-sm font-medium text-primary hover:bg-muted rounded-md"
                      >
                        {t(translations.login.bn, translations.login.en)}
                      </Link>
                      <Link
                        href="/auth/sign-up"
                        onClick={() => setMobileMenuOpen(false)}
                        className="px-3 py-2 text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 rounded-md text-center"
                      >
                        {t(translations.signup.bn, translations.signup.en)}
                      </Link>
                    </>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
