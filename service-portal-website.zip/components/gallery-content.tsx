'use client'

import { useState } from 'react'
import { useLanguage } from '@/lib/language-context'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { Image as ImageIcon, X, ZoomIn } from 'lucide-react'

interface GalleryItem {
  id: string
  title: string
  title_bn: string | null
  description: string | null
  description_bn: string | null
  image_url: string
  category: string
}

interface GalleryContentProps {
  gallery: GalleryItem[]
}

export function GalleryContent({ gallery }: GalleryContentProps) {
  const { t } = useLanguage()
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null)

  // Get unique categories
  const categories = Array.from(new Set(gallery.map(g => g.category)))

  // Filter gallery
  const filteredGallery = selectedCategory 
    ? gallery.filter(g => g.category === selectedCategory)
    : gallery

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('ফটো গ্যালারি', 'Photo Gallery')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'আমাদের কার্যক্রম ও ইভেন্টের ছবি দেখুন',
                'View photos of our activities and events'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      {categories.length > 0 && (
        <section className="py-6 bg-card border-b">
          <div className="container mx-auto px-4">
            <div className="flex gap-2 flex-wrap justify-center">
              <Button
                variant={selectedCategory === null ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(null)}
              >
                {t('সব', 'All')}
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Gallery Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {filteredGallery.length > 0 ? (
            <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {filteredGallery.map((item) => (
                <Card 
                  key={item.id} 
                  className="overflow-hidden cursor-pointer group"
                  onClick={() => setSelectedImage(item)}
                >
                  <CardContent className="p-0 relative">
                    <div className="aspect-square bg-muted">
                      <img
                        src={item.image_url}
                        alt={item.title}
                        className="size-full object-cover transition-transform group-hover:scale-105"
                      />
                    </div>
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                      <ZoomIn className="size-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
                      <p className="text-white text-sm font-medium line-clamp-1">
                        {t(item.title_bn || item.title, item.title)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <ImageIcon className="size-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {t('কোনো ছবি নেই', 'No Photos Found')}
              </h3>
              <p className="text-muted-foreground">
                {t('ছবি শীঘ্রই যোগ করা হবে', 'Photos will be added soon')}
              </p>
            </Card>
          )}
        </div>
      </section>

      {/* Lightbox Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <DialogTitle className="sr-only">
            {selectedImage ? t(selectedImage.title_bn || selectedImage.title, selectedImage.title) : 'Image'}
          </DialogTitle>
          {selectedImage && (
            <div className="relative">
              <img
                src={selectedImage.image_url}
                alt={selectedImage.title}
                className="w-full h-auto max-h-[80vh] object-contain"
              />
              <div className="p-4 bg-card">
                <h3 className="font-semibold">
                  {t(selectedImage.title_bn || selectedImage.title, selectedImage.title)}
                </h3>
                {selectedImage.description && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {t(selectedImage.description_bn || selectedImage.description, selectedImage.description)}
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
