'use client'

import { useLanguage } from '@/lib/language-context'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, Mail, Phone } from 'lucide-react'

interface Employee {
  id: string
  name: string
  name_bn: string | null
  designation: string
  designation_bn: string | null
  department: string | null
  department_bn: string | null
  phone: string | null
  email: string | null
  photo_url: string | null
  bio: string | null
  bio_bn: string | null
  join_date: string | null
}

interface EmployeesContentProps {
  employees: Employee[]
}

export function EmployeesContent({ employees }: EmployeesContentProps) {
  const { t } = useLanguage()

  // Group employees by department
  const departments = employees.reduce((acc, emp) => {
    const dept = emp.department || 'General'
    if (!acc[dept]) acc[dept] = []
    acc[dept].push(emp)
    return acc
  }, {} as Record<string, Employee[]>)

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('আমাদের কর্মচারী', 'Our Employees')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'আমাদের দক্ষ ও অভিজ্ঞ টিম সর্বদা আপনার সেবায় নিয়োজিত',
                'Our skilled and experienced team is always at your service'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Employee Directory */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {employees.length > 0 ? (
            Object.entries(departments).map(([department, deptEmployees]) => (
              <div key={department} className="mb-12 last:mb-0">
                <div className="flex items-center gap-3 mb-6">
                  <h2 className="text-xl font-bold">
                    {t(
                      deptEmployees[0]?.department_bn || department,
                      department
                    )}
                  </h2>
                  <Badge variant="secondary">
                    {deptEmployees.length} {t('জন', 'members')}
                  </Badge>
                </div>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {deptEmployees.map((employee) => (
                    <Card key={employee.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                      <CardContent className="p-0">
                        <div className="aspect-square bg-muted flex items-center justify-center">
                          {employee.photo_url ? (
                            <img
                              src={employee.photo_url}
                              alt={employee.name}
                              className="size-full object-cover"
                            />
                          ) : (
                            <Users className="size-16 text-muted-foreground" />
                          )}
                        </div>
                        <div className="p-4">
                          <h3 className="font-semibold text-lg mb-1">
                            {t(employee.name_bn || employee.name, employee.name)}
                          </h3>
                          <p className="text-sm text-primary font-medium mb-2">
                            {t(employee.designation_bn || employee.designation, employee.designation)}
                          </p>
                          {employee.bio && (
                            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                              {t(employee.bio_bn || employee.bio, employee.bio)}
                            </p>
                          )}
                          <div className="space-y-1.5">
                            {employee.phone && (
                              <a
                                href={`tel:${employee.phone}`}
                                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                              >
                                <Phone className="size-4" />
                                {employee.phone}
                              </a>
                            )}
                            {employee.email && (
                              <a
                                href={`mailto:${employee.email}`}
                                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                              >
                                <Mail className="size-4" />
                                {employee.email}
                              </a>
                            )}
                          </div>
                          {employee.join_date && (
                            <p className="text-xs text-muted-foreground mt-3 pt-3 border-t">
                              {t('যোগদান:', 'Joined:')} {new Date(employee.join_date).toLocaleDateString(t('bn-BD', 'en-US'))}
                            </p>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <Card className="p-12 text-center">
              <Users className="size-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {t('কোনো কর্মচারী নেই', 'No Employees Found')}
              </h3>
              <p className="text-muted-foreground">
                {t('কর্মচারী তথ্য শীঘ্রই যোগ করা হবে', 'Employee information will be added soon')}
              </p>
            </Card>
          )}
        </div>
      </section>
    </div>
  )
}
