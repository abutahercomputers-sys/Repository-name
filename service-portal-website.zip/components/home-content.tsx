'use client'

import Link from 'next/link'
import { useLanguage, translations } from '@/lib/language-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  FileText, 
  Users, 
  ClipboardCheck, 
  Bell, 
  Image as ImageIcon, 
  Phone,
  ArrowRight,
  CheckCircle,
  Clock,
  Shield
} from 'lucide-react'

// Types
interface Notice {
  id: string
  title: string
  title_bn: string | null
  published_at: string
  category: string
  is_pinned: boolean
}

interface Employee {
  id: string
  name: string
  name_bn: string | null
  designation: string
  designation_bn: string | null
  photo_url: string | null
}

interface HomeContentProps {
  notices: Notice[]
  employees: Employee[]
}

export function HomeContent({ notices, employees }: HomeContentProps) {
  const { t } = useLanguage()

  const services = [
    {
      icon: FileText,
      title: { bn: 'অনলাইন আবেদন', en: 'Online Application' },
      description: { 
        bn: 'বিভিন্ন সেবার জন্য ঘরে বসেই অনলাইনে আবেদন করুন', 
        en: 'Apply online for various services from the comfort of your home' 
      },
      href: '/apply',
    },
    {
      icon: ClipboardCheck,
      title: { bn: 'সনদ যাচাই', en: 'Certificate Verification' },
      description: { 
        bn: 'আপনার সনদ ও ডকুমেন্ট অনলাইনে যাচাই করুন', 
        en: 'Verify your certificates and documents online' 
      },
      href: '/verify',
    },
    {
      icon: Users,
      title: { bn: 'কর্মচারী তথ্য', en: 'Employee Directory' },
      description: { 
        bn: 'আমাদের কর্মচারীদের সম্পর্কে বিস্তারিত জানুন', 
        en: 'Learn about our team members and their roles' 
      },
      href: '/employees',
    },
    {
      icon: Bell,
      title: { bn: 'নোটিশ বোর্ড', en: 'Notice Board' },
      description: { 
        bn: 'সর্বশেষ নোটিশ ও ঘোষণা দেখুন', 
        en: 'View latest notices and announcements' 
      },
      href: '/notices',
    },
    {
      icon: ImageIcon,
      title: { bn: 'ফটো গ্যালারি', en: 'Photo Gallery' },
      description: { 
        bn: 'আমাদের কার্যক্রমের ছবি দেখুন', 
        en: 'Browse photos of our activities and events' 
      },
      href: '/gallery',
    },
    {
      icon: Phone,
      title: { bn: 'যোগাযোগ', en: 'Contact Us' },
      description: { 
        bn: 'আমাদের সাথে যোগাযোগ করুন', 
        en: 'Get in touch with us for any queries' 
      },
      href: '/contact',
    },
  ]

  const features = [
    { 
      icon: CheckCircle, 
      title: { bn: 'সহজ প্রক্রিয়া', en: 'Easy Process' },
      description: { bn: 'সরল ও সহজ আবেদন প্রক্রিয়া', en: 'Simple and straightforward application process' }
    },
    { 
      icon: Clock, 
      title: { bn: 'দ্রুত সেবা', en: 'Fast Service' },
      description: { bn: 'দ্রুত ও কার্যকর সেবা প্রদান', en: 'Quick and efficient service delivery' }
    },
    { 
      icon: Shield, 
      title: { bn: 'নিরাপদ ও গোপনীয়', en: 'Secure & Private' },
      description: { bn: 'আপনার তথ্য সুরক্ষিত', en: 'Your information is protected' }
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-primary to-accent py-16 md:py-24">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="container relative mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <Badge variant="secondary" className="mb-4">
              {t('অফিসিয়াল সার্ভিস পোর্টাল', 'Official Service Portal')}
            </Badge>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl lg:text-6xl mb-4">
              {t(translations.heroTitle.bn, translations.heroTitle.en)}
            </h1>
            <p className="text-lg md:text-xl mb-2 opacity-90">
              {t(translations.heroSubtitle.bn, translations.heroSubtitle.en)}
            </p>
            <p className="text-base md:text-lg mb-8 opacity-80 max-w-2xl mx-auto">
              {t(translations.heroDescription.bn, translations.heroDescription.en)}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link href="/apply">
                  {t(translations.applyNow.bn, translations.applyNow.en)}
                  <ArrowRight className="ml-2 size-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
                <Link href="/about">
                  {t(translations.learnMore.bn, translations.learnMore.en)}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="bg-card border-b py-6">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <feature.icon className="size-6" />
                </div>
                <div>
                  <h3 className="font-semibold">{t(feature.title.bn, feature.title.en)}</h3>
                  <p className="text-sm text-muted-foreground">{t(feature.description.bn, feature.description.en)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              {t(translations.featuredServices.bn, translations.featuredServices.en)}
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {t(
                'আমাদের বিভিন্ন অনলাইন সেবা সমূহ ব্যবহার করে সহজেই আপনার প্রয়োজনীয় কাজ সম্পন্ন করুন',
                'Complete your required tasks easily using our various online services'
              )}
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex size-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <service.icon className="size-6" />
                  </div>
                  <CardTitle className="text-lg">
                    {t(service.title.bn, service.title.en)}
                  </CardTitle>
                  <CardDescription>
                    {t(service.description.bn, service.description.en)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="ghost" className="p-0 h-auto text-primary" asChild>
                    <Link href={service.href}>
                      {t('বিস্তারিত দেখুন', 'Learn more')}
                      <ArrowRight className="ml-1 size-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Notices Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                {t(translations.latestNotices.bn, translations.latestNotices.en)}
              </h2>
              <p className="text-muted-foreground">
                {t('সর্বশেষ নোটিশ ও ঘোষণা', 'Latest notices and announcements')}
              </p>
            </div>
            <Button variant="outline" asChild>
              <Link href="/notices">
                {t(translations.viewAll.bn, translations.viewAll.en)}
                <ArrowRight className="ml-2 size-4" />
              </Link>
            </Button>
          </div>
          {notices.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {notices.slice(0, 6).map((notice) => (
                <Card key={notice.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-2 mb-2">
                      {notice.is_pinned && (
                        <Badge variant="destructive" className="text-xs">
                          {t('পিন করা', 'Pinned')}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs">
                        {notice.category}
                      </Badge>
                    </div>
                    <CardTitle className="text-base line-clamp-2">
                      {t(notice.title_bn || notice.title, notice.title)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {new Date(notice.published_at).toLocaleDateString(
                        t('bn-BD', 'en-US'),
                        { year: 'numeric', month: 'long', day: 'numeric' }
                      )}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">
                {t(translations.noData.bn, translations.noData.en)}
              </p>
            </Card>
          )}
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                {t(translations.ourTeam.bn, translations.ourTeam.en)}
              </h2>
              <p className="text-muted-foreground">
                {t('আমাদের দক্ষ কর্মী বাহিনী', 'Our skilled workforce')}
              </p>
            </div>
            <Button variant="outline" asChild>
              <Link href="/employees">
                {t(translations.viewAll.bn, translations.viewAll.en)}
                <ArrowRight className="ml-2 size-4" />
              </Link>
            </Button>
          </div>
          {employees.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {employees.slice(0, 4).map((employee) => (
                <Card key={employee.id} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="mx-auto mb-4 size-24 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                      {employee.photo_url ? (
                        <img 
                          src={employee.photo_url} 
                          alt={employee.name}
                          className="size-full object-cover"
                        />
                      ) : (
                        <Users className="size-10 text-muted-foreground" />
                      )}
                    </div>
                    <h3 className="font-semibold text-lg mb-1">
                      {t(employee.name_bn || employee.name, employee.name)}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {t(employee.designation_bn || employee.designation, employee.designation)}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">
                {t(translations.noData.bn, translations.noData.en)}
              </p>
            </Card>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            {t('আজই আবেদন করুন', 'Apply Today')}
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            {t(
              'আমাদের অনলাইন সেবা ব্যবহার করে ঘরে বসেই আপনার প্রয়োজনীয় কাজ সম্পন্ন করুন।',
              'Use our online services to complete your required tasks from home.'
            )}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/apply">
                {t(translations.applyNow.bn, translations.applyNow.en)}
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
              <Link href="/contact">
                {t(translations.contact.bn, translations.contact.en)}
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
