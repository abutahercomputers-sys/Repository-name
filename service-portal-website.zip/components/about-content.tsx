'use client'

import { useLanguage } from '@/lib/language-context'
import { Card, CardContent } from '@/components/ui/card'
import { Users, Target, Award, Heart } from 'lucide-react'

export function AboutContent() {
  const { t } = useLanguage()

  const stats = [
    { value: '৫০০+', valueEn: '500+', label: { bn: 'সক্রিয় সদস্য', en: 'Active Members' } },
    { value: '১০+', valueEn: '10+', label: { bn: 'বছরের অভিজ্ঞতা', en: 'Years Experience' } },
    { value: '১০০০+', valueEn: '1000+', label: { bn: 'সম্পন্ন সেবা', en: 'Services Completed' } },
    { value: '৯৮%', valueEn: '98%', label: { bn: 'সন্তুষ্টি হার', en: 'Satisfaction Rate' } },
  ]

  const values = [
    {
      icon: Target,
      title: { bn: 'আমাদের লক্ষ্য', en: 'Our Mission' },
      description: {
        bn: 'সমাজের সকল স্তরের মানুষের জন্য সহজ ও দ্রুত সেবা প্রদান করা এবং ডিজিটাল বাংলাদেশ গড়তে ভূমিকা রাখা।',
        en: 'To provide easy and fast services to people of all levels of society and contribute to building a digital Bangladesh.'
      }
    },
    {
      icon: Award,
      title: { bn: 'আমাদের দৃষ্টিভঙ্গি', en: 'Our Vision' },
      description: {
        bn: 'একটি সম্পূর্ণ ডিজিটাল সেবা প্ল্যাটফর্ম গড়ে তোলা যেখানে সকল সেবা একই জায়গায় পাওয়া যাবে।',
        en: 'To build a complete digital service platform where all services are available in one place.'
      }
    },
    {
      icon: Heart,
      title: { bn: 'আমাদের মূল্যবোধ', en: 'Our Values' },
      description: {
        bn: 'সততা, স্বচ্ছতা, দায়বদ্ধতা এবং জনগণের সেবায় নিবেদিত থাকা আমাদের মূল মূল্যবোধ।',
        en: 'Honesty, transparency, accountability, and dedication to public service are our core values.'
      }
    },
    {
      icon: Users,
      title: { bn: 'আমাদের টিম', en: 'Our Team' },
      description: {
        bn: 'আমাদের দক্ষ ও অভিজ্ঞ টিম সর্বদা আপনার সেবায় নিয়োজিত এবং সর্বোত্তম সেবা প্রদানে প্রতিশ্রুতিবদ্ধ।',
        en: 'Our skilled and experienced team is always at your service and committed to providing the best service.'
      }
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
              {t('আমাদের সম্পর্কে', 'About Us')}
            </h1>
            <p className="text-lg opacity-90">
              {t(
                'শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ - আপনার বিশ্বস্ত সেবা প্রদানকারী সংস্থা',
                'Shibpur Meghsimul Funny Content Group - Your trusted service provider organization'
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-card border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {t(stat.value, stat.valueEn)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {t(stat.label.bn, stat.label.en)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold mb-6 text-foreground">
                {t('আমাদের সম্পর্কে জানুন', 'Learn About Us')}
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {t(
                  'শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ বাংলাদেশের নেত্রকোণা জেলার পূর্বধলা উপজেলার শিবপুর/মেঘশিমূল এলাকায় অবস্থিত একটি সামাজিক সংগঠন। আমরা ২০১৫ সাল থেকে এলাকার মানুষের সেবায় নিয়োজিত রয়েছি।',
                  'Shibpur Meghsimul Funny Content Group is a social organization located in the Shibpur/Meghsimul area of Purbadhala Upazila, Netrokona District, Bangladesh. We have been serving the people of the area since 2015.'
                )}
              </p>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {t(
                  'আমাদের মূল উদ্দেশ্য হল এলাকার মানুষদের বিভিন্ন সরকারি ও বেসরকারি সেবা প্রাপ্তিতে সহায়তা করা, তথ্য প্রযুক্তির ব্যবহার বাড়ানো এবং সামাজিক উন্নয়নে অবদান রাখা।',
                  'Our main objective is to help the people of the area to get various government and private services, increase the use of information technology, and contribute to social development.'
                )}
              </p>
              <p className="text-muted-foreground leading-relaxed">
                {t(
                  'আমাদের এই অনলাইন পোর্টালের মাধ্যমে আপনি সহজেই বিভিন্ন সেবার জন্য আবেদন করতে পারবেন, সনদ যাচাই করতে পারবেন এবং আমাদের সাথে যোগাযোগ করতে পারবেন।',
                  'Through this online portal, you can easily apply for various services, verify certificates, and contact us.'
                )}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              {t('আমাদের মূল্যবোধ ও লক্ষ্য', 'Our Values & Goals')}
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {t(
                'আমরা যে মূল্যবোধ ও নীতিমালা অনুসরণ করি',
                'The values and principles we follow'
              )}
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {values.map((value, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <value.icon className="size-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">
                        {t(value.title.bn, value.title.en)}
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {t(value.description.bn, value.description.en)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
