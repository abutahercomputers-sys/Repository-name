'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

type Language = 'bn' | 'en'

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (bn: string, en: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('bn')

  useEffect(() => {
    const saved = localStorage.getItem('language') as Language
    if (saved) setLanguage(saved)
  }, [])

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem('language', lang)
  }

  const t = (bn: string, en: string) => (language === 'bn' ? bn : en)

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

// Translation dictionary
export const translations = {
  // Navigation
  home: { bn: 'হোম', en: 'Home' },
  about: { bn: 'আমাদের সম্পর্কে', en: 'About Us' },
  services: { bn: 'সেবাসমূহ', en: 'Services' },
  employees: { bn: 'কর্মচারী', en: 'Employees' },
  apply: { bn: 'আবেদন করুন', en: 'Apply Online' },
  notices: { bn: 'নোটিশ বোর্ড', en: 'Notice Board' },
  gallery: { bn: 'গ্যালারি', en: 'Gallery' },
  contact: { bn: 'যোগাযোগ', en: 'Contact' },
  login: { bn: 'লগইন', en: 'Login' },
  signup: { bn: 'নিবন্ধন', en: 'Sign Up' },
  logout: { bn: 'লগআউট', en: 'Logout' },
  dashboard: { bn: 'ড্যাশবোর্ড', en: 'Dashboard' },
  admin: { bn: 'অ্যাডমিন', en: 'Admin' },
  
  // Hero Section
  heroTitle: { 
    bn: 'শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ', 
    en: 'Shibpur Meghsimul Funny Content Group' 
  },
  heroSubtitle: { 
    bn: 'শিবপুর/মেঘশিমূল, পূর্বধলা, নেত্রকোণা, বাংলাদেশ', 
    en: 'Shibpur/Meghsimul, Purbadhala, Netrokona, Bangladesh' 
  },
  heroDescription: { 
    bn: 'আমাদের অফিসিয়াল সার্ভিস পোর্টালে স্বাগতম। এখানে আপনি অনলাইনে আবেদন করতে, সনদ যাচাই করতে এবং বিভিন্ন সেবা গ্রহণ করতে পারবেন।', 
    en: 'Welcome to our official service portal. Here you can apply online, verify certificates, and access various community services.' 
  },
  
  // Buttons
  applyNow: { bn: 'এখনই আবেদন করুন', en: 'Apply Now' },
  learnMore: { bn: 'আরও জানুন', en: 'Learn More' },
  viewAll: { bn: 'সব দেখুন', en: 'View All' },
  submit: { bn: 'জমা দিন', en: 'Submit' },
  cancel: { bn: 'বাতিল', en: 'Cancel' },
  save: { bn: 'সংরক্ষণ', en: 'Save' },
  edit: { bn: 'সম্পাদনা', en: 'Edit' },
  delete: { bn: 'মুছুন', en: 'Delete' },
  
  // Form Labels
  fullName: { bn: 'পূর্ণ নাম', en: 'Full Name' },
  email: { bn: 'ইমেইল', en: 'Email' },
  phone: { bn: 'মোবাইল নম্বর', en: 'Phone Number' },
  address: { bn: 'ঠিকানা', en: 'Address' },
  password: { bn: 'পাসওয়ার্ড', en: 'Password' },
  confirmPassword: { bn: 'পাসওয়ার্ড নিশ্চিত করুন', en: 'Confirm Password' },
  fatherName: { bn: 'পিতার নাম', en: "Father's Name" },
  motherName: { bn: 'মাতার নাম', en: "Mother's Name" },
  nidNumber: { bn: 'জাতীয় পরিচয়পত্র নম্বর', en: 'NID Number' },
  birthDate: { bn: 'জন্ম তারিখ', en: 'Date of Birth' },
  subject: { bn: 'বিষয়', en: 'Subject' },
  message: { bn: 'বার্তা', en: 'Message' },
  
  // Status
  pending: { bn: 'অপেক্ষমাণ', en: 'Pending' },
  processing: { bn: 'প্রক্রিয়াধীন', en: 'Processing' },
  approved: { bn: 'অনুমোদিত', en: 'Approved' },
  rejected: { bn: 'বাতিল', en: 'Rejected' },
  
  // Sections
  featuredServices: { bn: 'আমাদের সেবাসমূহ', en: 'Our Services' },
  latestNotices: { bn: 'সাম্প্রতিক নোটিশ', en: 'Latest Notices' },
  ourTeam: { bn: 'আমাদের টিম', en: 'Our Team' },
  quickLinks: { bn: 'দ্রুত লিঙ্ক', en: 'Quick Links' },
  contactInfo: { bn: 'যোগাযোগের তথ্য', en: 'Contact Information' },
  
  // Footer
  copyright: { 
    bn: '© ২০২৬ শিবপুর মেঘশিমূল ফানি কন্টেন্ট গ্রুপ। সর্বস্বত্ব সংরক্ষিত।', 
    en: '© 2026 Shibpur Meghsimul Funny Content Group. All rights reserved.' 
  },
  
  // Misc
  loading: { bn: 'লোড হচ্ছে...', en: 'Loading...' },
  noData: { bn: 'কোনো তথ্য নেই', en: 'No data available' },
  error: { bn: 'ত্রুটি হয়েছে', en: 'An error occurred' },
  success: { bn: 'সফল হয়েছে', en: 'Success' },
}
